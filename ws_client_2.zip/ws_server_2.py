# server.py
import asyncio
import websockets
import threading
import sys

clients = set()

async def handler(websocket, path):
    clients.add(websocket)
    print("Client connected")
    try:
        async for message in websocket:
            print(f"Received message from client: {message}")
    except websockets.ConnectionClosed:
        print("Client disconnected")
    finally:
        clients.remove(websocket)

async def main():
    async with websockets.serve(handler, "localhost", 8080):
        print("WebSocket server is running on ws://localhost:8080")
        await asyncio.Future()  # run forever

def start_server():
    asyncio.run(main())

def send_message():
    while True:
        message = input("Server: ")
        if message:
            # Send message to all connected clients
            for client in clients:
                asyncio.run(client.send(message))

if __name__ == "__main__":
    # Start the WebSocket server in a separate thread
    threading.Thread(target=start_server, daemon=True).start()
    # Start sending messages from the keyboard
    send_message()
